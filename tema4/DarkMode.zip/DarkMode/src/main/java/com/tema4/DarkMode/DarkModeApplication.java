package com.tema4.DarkMode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DarkModeApplication {

	public static void main(String[] args) {
		SpringApplication.run(DarkModeApplication.class, args);
	}

}
