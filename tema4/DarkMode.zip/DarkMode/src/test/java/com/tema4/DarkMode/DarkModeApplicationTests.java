package com.tema4.DarkMode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DarkModeApplicationTests {

	@Test
	void contextLoads() {
	}

}
